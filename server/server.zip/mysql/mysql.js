const mysqlConfig= {
    host:'47.100.34.194',
    // host:'127.0.0.1',
    port:'3306',
    user:'root',
    password:'Wxw123456',
    // password:'123456789',
    database:'test1'
}
module.exports = mysqlConfig;